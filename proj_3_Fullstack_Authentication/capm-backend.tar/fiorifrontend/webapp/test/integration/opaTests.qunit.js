/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["masterdetail/masterdetail/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
