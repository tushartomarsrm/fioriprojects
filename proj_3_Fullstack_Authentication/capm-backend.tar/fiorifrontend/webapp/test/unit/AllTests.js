sap.ui.define([
	"masterdetail/masterdetail/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
