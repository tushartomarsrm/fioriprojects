sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/m/MessageToast"
], function (Controller, JSONModel, MessageBox, MessageToast) {
    "use strict";

    return Controller.extend("fiorifrontend.fiorifrontend.controller.Dashboard", {
        onInit: function () {
            const oRouter = this.getOwnerComponent().getRouter();
            oRouter.getRoute("dashboard").attachPatternMatched(this._onRouteMatched, this);
        },

        _onRouteMatched: function () {
            // Check if user is logged in
            const token = sessionStorage.getItem("authToken");
            const userEmail = sessionStorage.getItem("userEmail");
            const userId = sessionStorage.getItem("userId");

            if (!token || !userEmail) {
                MessageToast.show("Please login to access dashboard");
                this.getOwnerComponent().getRouter().navTo("login");
                return;
            }

            // Set user data to view model
            const oViewModel = new JSONModel({
                userEmail: userEmail,
                userId: userId,
                token: token
            });
            this.getView().setModel(oViewModel);
        },

        onLogout: function () {
            MessageBox.confirm("Are you sure you want to logout?", {
                onClose: (oAction) => {
                    if (oAction === MessageBox.Action.OK) {
                        // Clear session storage
                        sessionStorage.removeItem("authToken");
                        sessionStorage.removeItem("userEmail");
                        sessionStorage.removeItem("userId");

                        MessageToast.show("Logged out successfully");
                        this.getOwnerComponent().getRouter().navTo("home");
                    }
                }
            });
        },

        onViewProfile: function () {
            MessageToast.show("Profile view - Feature coming soon!");
        },

        onUpdateSettings: function () {
            MessageToast.show("Settings - Feature coming soon!");
        },

        onChangePassword: function () {
            MessageToast.show("Change password - Feature coming soon!");
        }
    });
});