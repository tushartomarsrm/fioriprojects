sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/m/MessageToast"
], function (Controller, JSONModel, MessageBox, MessageToast) {
    "use strict";

    return Controller.extend("fiorifrontend.fiorifrontend.controller.ResetPassword", {
        onInit: function () {
            const oRouter = this.getOwnerComponent().getRouter();
            oRouter.getRoute("resetPassword").attachPatternMatched(this._onRouteMatched, this);
        },

        _onRouteMatched: function () {
            const email = sessionStorage.getItem("resetEmail");
            
            if (!email) {
                MessageToast.show("Please request a password reset first.");
                this.getOwnerComponent().getRouter().navTo("forgotPassword");
                return;
            }

            const oViewModel = new JSONModel({
                email: email,
                otp: "",
                newPassword: "",
                confirmPassword: "",
                otpState: "None",
                otpStateText: "",
                newPasswordState: "None",
                newPasswordStateText: "",
                confirmPasswordState: "None",
                confirmPasswordStateText: ""
            });
            this.getView().setModel(oViewModel);
        },

        onNavBack: function () {
            this.getOwnerComponent().getRouter().navTo("forgotPassword");
        },

        validateOTP: function (otp) {
            return otp && otp.length === 6 && /^\d+$/.test(otp);
        },

        validateForm: function () {
            const oModel = this.getView().getModel();
            const otp = oModel.getProperty("/otp");
            const newPassword = oModel.getProperty("/newPassword");
            const confirmPassword = oModel.getProperty("/confirmPassword");
            let isValid = true;

            // Reset states
            oModel.setProperty("/otpState", "None");
            oModel.setProperty("/newPasswordState", "None");
            oModel.setProperty("/confirmPasswordState", "None");

            // Validate OTP
            if (!this.validateOTP(otp)) {
                oModel.setProperty("/otpState", "Error");
                oModel.setProperty("/otpStateText", "Please enter a valid 6-digit OTP");
                isValid = false;
            }

            // Validate new password
            if (!newPassword) {
                oModel.setProperty("/newPasswordState", "Error");
                oModel.setProperty("/newPasswordStateText", "Password is required");
                isValid = false;
            } else if (newPassword.length < 6) {
                oModel.setProperty("/newPasswordState", "Error");
                oModel.setProperty("/newPasswordStateText", "Password must be at least 6 characters");
                isValid = false;
            }

            // Validate confirm password
            if (!confirmPassword) {
                oModel.setProperty("/confirmPasswordState", "Error");
                oModel.setProperty("/confirmPasswordStateText", "Please confirm your password");
                isValid = false;
            } else if (newPassword !== confirmPassword) {
                oModel.setProperty("/confirmPasswordState", "Error");
                oModel.setProperty("/confirmPasswordStateText", "Passwords do not match");
                isValid = false;
            }

            return isValid;
        },

        onResetPassword: function () {
            if (!this.validateForm()) {
                MessageToast.show("Please fix the validation errors");
                return;
            }

            const oModel = this.getView().getModel();
            const email = oModel.getProperty("/email");
            const otp = oModel.getProperty("/otp");
            const newPassword = oModel.getProperty("/newPassword");

            // Disable button
            this.byId("resetButton").setEnabled(false);

            // Call backend resetPassword action
            fetch("/odata/v4/user/resetPassword", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    email: email,
                    otp: otp,
                    newPassword: newPassword
                })
            })
            .then(response => response.json())
            .then(data => {
                this.byId("resetButton").setEnabled(true);

                if (data.success) {
                    sessionStorage.removeItem("resetEmail");
                    
                    MessageBox.success(data.message, {
                        onClose: () => {
                            this.getOwnerComponent().getRouter().navTo("login");
                        }
                    });
                } else {
                    const errorMessage = data.message || "Password reset failed";
                    MessageBox.error(errorMessage);
                }
            })
            .catch(error => {
                this.byId("resetButton").setEnabled(true);
                MessageBox.error("Network error. Please try again.");
                console.error("Reset password error:", error);
            });
        },

        onResendOTP: function () {
            const oModel = this.getView().getModel();
            const email = oModel.getProperty("/email");

            fetch("/odata/v4/user/forgotPassword", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    email: email
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    MessageToast.show("New OTP sent to your email");
                } else {
                    MessageBox.error("Failed to resend OTP");
                }
            })
            .catch(error => {
                MessageBox.error("Network error. Please try again.");
                console.error("Resend OTP error:", error);
            });
        }
    });
});