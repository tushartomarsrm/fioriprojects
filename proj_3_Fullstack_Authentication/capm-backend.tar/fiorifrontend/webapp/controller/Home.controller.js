
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/routing/History"
], function (Controller, History) {
    "use strict";

    return Controller.extend("fiorifrontend.fiorifrontend.controller.Home", {
        onInit: function () {
            // Check if user is already logged in
            const token = sessionStorage.getItem("authToken");
            if (token) {
                this.getOwnerComponent().getRouter().navTo("dashboard");
            }
        },

        onLogin: function () {
            this.getOwnerComponent().getRouter().navTo("login");
        },

        onSignup: function () {
            this.getOwnerComponent().getRouter().navTo("signup");
        }
    });
});