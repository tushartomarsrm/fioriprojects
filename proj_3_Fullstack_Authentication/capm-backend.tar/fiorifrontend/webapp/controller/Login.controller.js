sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/m/MessageToast"
], function (Controller, JSONModel, MessageBox, MessageToast) {
    "use strict";

    return Controller.extend("fiorifrontend.fiorifrontend.controller.Login", {
        onInit: function () {
            // Initialize view model
            const oViewModel = new JSONModel({
                email: "",
                password: "",
                emailState: "None",
                emailStateText: "",
                passwordState: "None",
                passwordStateText: ""
            });
            this.getView().setModel(oViewModel);
        },

        onNavBack: function () {
            this.getOwnerComponent().getRouter().navTo("home");
        },

        validateEmail: function (email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        },

        validateForm: function () {
            const oModel = this.getView().getModel();
            const email = oModel.getProperty("/email");
            const password = oModel.getProperty("/password");
            let isValid = true;

            // Reset states
            oModel.setProperty("/emailState", "None");
            oModel.setProperty("/passwordState", "None");

            // Validate email
            if (!email) {
                oModel.setProperty("/emailState", "Error");
                oModel.setProperty("/emailStateText", "Email is required");
                isValid = false;
            } else if (!this.validateEmail(email)) {
                oModel.setProperty("/emailState", "Error");
                oModel.setProperty("/emailStateText", "Invalid email format");
                isValid = false;
            }

            // Validate password
            if (!password) {
                oModel.setProperty("/passwordState", "Error");
                oModel.setProperty("/passwordStateText", "Password is required");
                isValid = false;
            }

            return isValid;
        },

        onLogin: function () {
            if (!this.validateForm()) {
                MessageToast.show("Please fix the validation errors");
                return;
            }

            const oModel = this.getView().getModel();
            const email = oModel.getProperty("/email");
            const password = oModel.getProperty("/password");

            // Disable button
            this.byId("loginButton").setEnabled(false);

            // Call backend login action
            fetch("/odata/v4/user/login", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    email: email,
                    password: password
                })
            })
            .then(response => response.json())
            .then(data => {
                this.byId("loginButton").setEnabled(true);

                if (data.success) {
                    // Store auth token and user info
                    sessionStorage.setItem("authToken", data.token);
                    sessionStorage.setItem("userEmail", data.user.email);
                    sessionStorage.setItem("userId", data.user.ID);

                    MessageBox.success(data.message, {
                        onClose: () => {
                            this.getOwnerComponent().getRouter().navTo("dashboard");
                        }
                    });
                } else {
                    const errorMessage = data.message || "Login failed";
                    
                    MessageBox.error(errorMessage);
                }
            })
            .catch(error => {
                this.byId("loginButton").setEnabled(true);
                MessageBox.error("Network error. Please try again.");
                console.error("Login error:", error);
            });
        },

        onForgotPassword: function () {
            this.getOwnerComponent().getRouter().navTo("forgotPassword");
        },

        onNavigateToSignup: function () {
            this.getOwnerComponent().getRouter().navTo("signup");
        }
    });
});