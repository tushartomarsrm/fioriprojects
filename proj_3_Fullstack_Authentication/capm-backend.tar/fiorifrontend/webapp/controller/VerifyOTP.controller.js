sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/m/MessageToast"
], function (Controller, JSONModel, MessageBox, MessageToast) {
    "use strict";

    return Controller.extend("fiorifrontend.fiorifrontend.controller.VerifyOTP", {
        onInit: function () {
            const oRouter = this.getOwnerComponent().getRouter();
            oRouter.getRoute("verify").attachPatternMatched(this._onRouteMatched, this);
        },

        _onRouteMatched: function () {
            const email = sessionStorage.getItem("pendingEmail");

            if (!email) {
                MessageToast.show("No pending verification. Please signup first.");
                this.getOwnerComponent().getRouter().navTo("signup");
                return;
            }

            const oViewModel = new JSONModel({
                email: email,
                otp: "",
                otpState: "None",
                otpStateText: ""
            });
            this.getView().setModel(oViewModel);
        },

        onNavBack: function () {
            this.getOwnerComponent().getRouter().navTo("home");
        },

        validateOTP: function (otp) {
            return otp && otp.length === 6 && /^\d+$/.test(otp);
        },

        onVerify: function () {
            const oModel = this.getView().getModel();
            const email = oModel.getProperty("/email");
            const otp = oModel.getProperty("/otp");

            // Reset state
            oModel.setProperty("/otpState", "None");

            // Validate OTP
            if (!this.validateOTP(otp)) {
                oModel.setProperty("/otpState", "Error");
                oModel.setProperty("/otpStateText", "Please enter a valid 6-digit OTP");
                return;
            }

            // Disable button
            this.byId("verifyButton").setEnabled(false);

            // Call backend verifyOTP action
            fetch("/odata/v4/user/verifyOTP", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    email: email,
                    otp: otp
                })
            })
                .then(response => response.json())

                .then(data => {
                    this.byId("verifyButton").setEnabled(true);

                    if (data.success) {
                        sessionStorage.setItem("authToken", data.token);
                        sessionStorage.removeItem("pendingEmail");

                        MessageBox.success(data.message, {
                            onClose: () => {
                                this.getOwnerComponent().getRouter().navTo("dashboard");
                            }
                        });
                    } else {
                        MessageBox.error(data.message || "Verification failed");
                    }

                })
                .catch(error => {
                    this.byId("verifyButton").setEnabled(true);
                    MessageBox.error("Network error. Please try again.");
                    console.error("Verification error:", error);
                });
        },

        onResendOTP: function () {
            const oModel = this.getView().getModel();
            const email = oModel.getProperty("/email");

            fetch("/odata/v4/user/resendOTP", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    email: email
                })
            })
                .then(response => response.json())
                .then(data => {

                    if (data.success) {
                        MessageToast.show(data.message);
                    } else {
                        MessageBox.error(data.message || "Failed to resend OTP");
                    }


                })
                .catch(error => {
                    MessageBox.error("Network error. Please try again.");
                    console.error("Resend OTP error:", error);
                });
        }
    });
});
