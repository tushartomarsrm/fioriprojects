sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("fiorifrontend.fiorifrontend.controller.App", {
      onInit() {
      }
  });
});
