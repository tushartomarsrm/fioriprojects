sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/m/MessageToast"
], function (Controller, JSONModel, MessageBox, MessageToast) {
    "use strict";

    return Controller.extend("fiorifrontend.fiorifrontend.controller.Signup", {
        onInit: function () {
            // Initialize view model
            const oViewModel = new JSONModel({
                email: "",
                password: "",
                confirmPassword: "",
                emailState: "None",
                emailStateText: "",
                passwordState: "None",
                passwordStateText: "",
                confirmPasswordState: "None",
                confirmPasswordStateText: ""
            });
            this.getView().setModel(oViewModel);
        },

        onNavBack: function () {
            this.getOwnerComponent().getRouter().navTo("home");
        },

        validateEmail: function (email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        },

        validateForm: function () {
            const oModel = this.getView().getModel();
            const email = oModel.getProperty("/email");
            const password = oModel.getProperty("/password");
            const confirmPassword = oModel.getProperty("/confirmPassword");
            let isValid = true;

            // Reset states
            oModel.setProperty("/emailState", "None");
            oModel.setProperty("/passwordState", "None");
            oModel.setProperty("/confirmPasswordState", "None");

            // Validate email
            if (!email) {
                oModel.setProperty("/emailState", "Error");
                oModel.setProperty("/emailStateText", "Email is required");
                isValid = false;
            } else if (!this.validateEmail(email)) {
                oModel.setProperty("/emailState", "Error");
                oModel.setProperty("/emailStateText", "Invalid email format");
                isValid = false;
            }

            // Validate password
            if (!password) {
                oModel.setProperty("/passwordState", "Error");
                oModel.setProperty("/passwordStateText", "Password is required");
                isValid = false;
            } else if (password.length < 6) {
                oModel.setProperty("/passwordState", "Error");
                oModel.setProperty("/passwordStateText", "Password must be at least 6 characters");
                isValid = false;
            }

            // Validate confirm password
            if (!confirmPassword) {
                oModel.setProperty("/confirmPasswordState", "Error");
                oModel.setProperty("/confirmPasswordStateText", "Please confirm your password");
                isValid = false;
            } else if (password !== confirmPassword) {
                oModel.setProperty("/confirmPasswordState", "Error");
                oModel.setProperty("/confirmPasswordStateText", "Passwords do not match");
                isValid = false;
            }

            return isValid;
        },

        onSignup: function () {
            if (!this.validateForm()) {
                MessageToast.show("Please fix the validation errors");
                return;
            }

            const oModel = this.getView().getModel();
            const email = oModel.getProperty("/email");
            const password = oModel.getProperty("/password");

            // Disable button during processing
            this.byId("signupButton").setEnabled(false);

            // Call backend signup action
            fetch("/odata/v4/user/signup", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ email, password })
            })
                .then(async response => {
                    const data = await response.json();
                    if (!response.ok) {
                        throw data;
                    }
                    return data;
                })
                .then(data => {
                    this.byId("signupButton").setEnabled(true);

                    MessageBox.success(data.message, {
                        onClose: () => {
                            sessionStorage.setItem("pendingEmail", email);
                            this.getOwnerComponent().getRouter().navTo("verify");
                        }
                    });
                })
                .catch(error => {
                    this.byId("signupButton").setEnabled(true);
                    MessageBox.error(error.message || "Signup failed");
                    console.error("Signup error:", error);
                });

        },

        onNavigateToLogin: function () {
            this.getOwnerComponent().getRouter().navTo("login");
        }
    });
});