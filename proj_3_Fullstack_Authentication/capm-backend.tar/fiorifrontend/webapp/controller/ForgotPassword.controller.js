sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/m/MessageToast"
], function (Controller, JSONModel, MessageBox, MessageToast) {
    "use strict";

    return Controller.extend("fiorifrontend.fiorifrontend.controller.ForgotPassword", {
        onInit: function () {
            const oViewModel = new JSONModel({
                email: "",
                emailState: "None",
                emailStateText: ""
            });
            this.getView().setModel(oViewModel);
        },

        onNavBack: function () {
            this.getOwnerComponent().getRouter().navTo("login");
        },

        validateEmail: function (email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        },

        onSendOTP: function () {
            const oModel = this.getView().getModel();
            const email = oModel.getProperty("/email");

            // Reset state
            oModel.setProperty("/emailState", "None");

            // Validate email
            if (!email) {
                oModel.setProperty("/emailState", "Error");
                oModel.setProperty("/emailStateText", "Email is required");
                return;
            }

            if (!this.validateEmail(email)) {
                oModel.setProperty("/emailState", "Error");
                oModel.setProperty("/emailStateText", "Invalid email format");
                return;
            }

            // Disable button
            this.byId("sendOTPButton").setEnabled(false);

            // Call backend forgotPassword action
            fetch("/odata/v4/user/forgotPassword", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    email: email
                })
            })
            .then(response => response.json())
            .then(data => {
                this.byId("sendOTPButton").setEnabled(true);

                if (data.success) {
                    MessageBox.success(data.message, {
                        onClose: () => {
                            // Store email for password reset
                            sessionStorage.setItem("resetEmail", email);
                            this.getOwnerComponent().getRouter().navTo("resetPassword");
                        }
                    });
                } else {
                    const errorMessage = data.message || "Failed to send OTP";
                    MessageBox.error(errorMessage);
                }
            })
            .catch(error => {
                this.byId("sendOTPButton").setEnabled(true);
                MessageBox.error("Network error. Please try again.");
                console.error("Forgot password error:", error);
            });
        },

        onNavigateToLogin: function () {
            this.getOwnerComponent().getRouter().navTo("login");
        }
    });
});