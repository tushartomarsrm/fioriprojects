## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Mon Feb 09 2026 13:19:22 GMT+0000 (Coordinated Universal Time)|
|**App Generator**<br>SAP Fiori Application Generator|
|**App Generator Version**<br>1.20.2|
|**Generation Platform**<br>SAP Business Application Studio|
|**Template Used**<br>Basic|
|**Service Type**<br>None|
|**Service URL**<br>N/A|
|**Module Name**<br>fiorifrontend|
|**Application Title**<br>fiorifrontend|
|**Namespace**<br>fiorifrontend|
|**UI5 Theme**<br>sap_horizon|
|**UI5 Version**<br>1.144.1|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>False|

## fiorifrontend

An SAP Fiori application.

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  To launch the generated application, run the following from the generated application root folder:

```
    npm start
```

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


