const cds = require('@sap/cds');
const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');
require('dotenv').config();




class UserService extends cds.ApplicationService {
  async init() {
    const { Users } = this.entities;

    /* =======================
       Mail Transporter
    ======================== */
    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 587,
      secure: false,
      auth: {
        user: "",
        pass: ""
      }
    });

    /* =======================
       Helper Functions
    ======================== */
    const generateOTP = () =>
      Math.floor(100000 + Math.random() * 900000).toString();

    const sendEmail = async (to, subject, html) => {
      try {
        await transporter.sendMail({
          from: process.env.EMAIL_USER,
          to,
          subject,
          html
        });
        return true;
      } catch (err) {
        console.error('Email error:', err);
        return false;
      }
    };

    /* =======================
       Signup
    ======================== */
    this.on('signup', async (req) => {
      const { email, password } = req.data;

      if (!email || !password)
        return { success: false, message: 'Email and password are required' };

      if (password.length < 6)
        return { success: false, message: 'Password must be at least 6 characters' };

      const existing = await SELECT.one.from(Users).where({ email });

      if (existing) {
        if (existing.isVerified)
          return { success: false, message: 'Email already registered' };

        await DELETE.from(Users).where({ email });
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      const otp = generateOTP();
      const otpExpiry = new Date(Date.now() + 10 * 60 * 1000);

      await INSERT.into(Users).entries({
        email,
        password: hashedPassword,
        isVerified: false,
        otp,
        otpExpiry,
        createdAt: new Date(),
        updatedAt: new Date()
      });

      let sent = false;

try {
  sent = await sendEmail(
    email,
    'Verify Your Account - OTP',
    `<h2>Your OTP: ${otp}</h2><p>Valid for 10 minutes</p>`
  );
} catch (err) {
  console.error("❌ Email send failed:", err);
  sent = false;
}

if (!sent) {
  return {
    success: false,
    message: "Failed to send verification email. Please try again."
  };
}


      if (!sent)
        return { success: false, message: 'Failed to send OTP email' };

      return { success: true, message: 'Signup successful. OTP sent.' };
    });

    /* =======================
       Verify OTP
    ======================== */
    this.on('verifyOTP', async (req) => {
      const { email, otp } = req.data;

      const user = await SELECT.one.from(Users).where({ email });
      if (!user) return { success: false, message: 'User not found' };
      if (user.isVerified) return { success: false, message: 'Already verified' };
      if (new Date() > new Date(user.otpExpiry))
        return { success: false, message: 'OTP expired' };
      if (user.otp !== otp)
        return { success: false, message: 'Invalid OTP' };

      await UPDATE(Users).set({
        isVerified: true,
        otp: null,
        otpExpiry: null,
        updatedAt: new Date()
      }).where({ email });

      return { success: true, message: 'Account verified' };
    });

    /* =======================
       Login
    ======================== */
    this.on('login', async (req) => {
      const { email, password } = req.data;

      const user = await SELECT.one.from(Users).where({ email });
      if (!user || !user.isVerified)
        return { success: false, message: 'Invalid credentials' };

      const valid = await bcrypt.compare(password, user.password);
      if (!valid)
        return { success: false, message: 'Invalid credentials' };

      return {
        success: true,
        message: 'Login successful',
        user: { ID: user.ID, email: user.email }
      };
    });

    /* =======================
       Forgot Password
    ======================== */
    this.on('forgotPassword', async (req) => {
      const { email } = req.data;

      const user = await SELECT.one.from(Users).where({ email });
      if (!user)
        return { success: true, message: 'If email exists, OTP was sent' };

      const otp = generateOTP();
      const otpExpiry = new Date(Date.now() + 10 * 60 * 1000);

      await UPDATE(Users).set({ otp, otpExpiry }).where({ email });

      await sendEmail(
        email,
        'Password Reset OTP',
        `<h2>Your OTP: ${otp}</h2>`
      );

      return { success: true, message: 'Reset OTP sent' };
    });

    /* =======================
       Reset Password
    ======================== */
    this.on('resetPassword', async (req) => {
      const { email, otp, newPassword } = req.data;

      const user = await SELECT.one.from(Users).where({ email });
      if (!user) return { success: false, message: 'Invalid request' };
      if (user.otp !== otp)
        return { success: false, message: 'Invalid OTP' };
      if (new Date() > new Date(user.otpExpiry))
        return { success: false, message: 'OTP expired' };

      const hashed = await bcrypt.hash(newPassword, 10);

      await UPDATE(Users).set({
        password: hashed,
        otp: null,
        otpExpiry: null,
        updatedAt: new Date()
      }).where({ email });

      return { success: true, message: 'Password reset successful' };
    });

    /* =======================
       Resend OTP
    ======================== */
    this.on('resendOTP', async (req) => {
      const { email } = req.data;

      const user = await SELECT.one.from(Users).where({ email });
      if (!user || user.isVerified)
        return { success: false, message: 'Invalid request' };

      const otp = generateOTP();
      const otpExpiry = new Date(Date.now() + 10 * 60 * 1000);

      await UPDATE(Users).set({ otp, otpExpiry }).where({ email });

      await sendEmail(
        email,
        'New Verification OTP',
        `<h2>Your OTP: ${otp}</h2>`
      );

      return { success: true, message: 'OTP resent successfully' };
    });

    // 🔴 MUST be last
    await super.init();
  }
}

module.exports = UserService;
