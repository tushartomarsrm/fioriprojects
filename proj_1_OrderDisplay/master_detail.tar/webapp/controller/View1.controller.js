sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/Dialog",
    "sap/m/Text",
    "sap/m/Button",
    "sap/m/VBox"
], function (
    Controller,
    Filter,
    FilterOperator,
    Dialog,
    Text,
    Button,
    VBox
) {
    "use strict";

    return Controller.extend("masterdetail.masterdetail.controller.View1", {

        //customer based search
        onSearch: function (oEvent) {
            var sQuery = oEvent.getParameter("query") || oEvent.getParameter("newValue");
            var oFlexBox = this.byId("cardBox");
            var oBinding = oFlexBox.getBinding("items");

            if (!oBinding) {
                return;
            }

            if (sQuery && sQuery.trim()) {
                var oFilter = new Filter(
                    "CustomerID",
                    FilterOperator.Contains,
                    sQuery
                );
                oBinding.filter(oFilter);
            } else {
                oBinding.filter([]);
            }
        },

        //Dialog box
        onCardPress: function (oEvent) {
    var oData = oEvent.getSource().getBindingContext().getObject();

    if (this._oDialog) {
        this._oDialog.destroy();
    }

    this._oDialog = new sap.m.Dialog({
        title: "Order Details",
        contentWidth: "480px",
        resizable: true,
        draggable: true,
        verticalScrolling: true,
        stretchOnPhone: true,

        content: [
            new sap.m.ObjectHeader({
                title: "Order #" + oData.OrderID,
                number: oData.OrderID,
                numberUnit: "ID",
                intro: "Customer: " + oData.CustomerID,
                icon: "sap-icon://sales-order",
                attributes: [
                    new sap.m.ObjectAttribute({
                        title: "Ship Country",
                        text: oData.ShipCountry
                    }),
                    new sap.m.ObjectAttribute({
                        title: "Ship City",
                        text: oData.ShipCity
                    })
                ],
                statuses: [
                    new sap.m.ObjectStatus({
                        text: oData.ShippedDate ? "Shipped" : "Not Shipped",
                        state: oData.ShippedDate ? "Success" : "Warning"
                    })
                ]
            }),
            new sap.m.Panel({
                headerText: "Order Information",
                class: "sapUiSmallMarginTop",
                content: new sap.m.VBox({
                    items: [
                        new sap.m.Text({ text: "Order Date: " + oData.OrderDate }),
                        new sap.m.Text({ text: "Required Date: " + oData.RequiredDate }),
                        new sap.m.Text({ text: "Shipped Date: " + (oData.ShippedDate || "N/A") }),
                        new sap.m.Text({ text: "Freight: $" + oData.Freight })
                    ]
                })
            })
        ],

        beginButton: new sap.m.Button({
            text: "Close",
            type: "Emphasized",
            press: function () {
                this._oDialog.close();
            }.bind(this)
        }),

        afterClose: function () {
            this._oDialog.destroy();
            this._oDialog = null;
        }.bind(this)
    });

    this._oDialog.open();
}


    });
});
